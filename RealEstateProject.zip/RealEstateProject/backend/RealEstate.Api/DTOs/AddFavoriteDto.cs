﻿public class AddFavoriteDto
{
    public int PropertyId { get; set; }
}
